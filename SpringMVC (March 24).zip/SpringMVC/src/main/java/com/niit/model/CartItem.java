package com.niit.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;



import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class CartItem implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int quantity;
	private double totalPrice;
	@ManyToOne
	@JoinColumn(name="product_id")
	private Product product;
	@ManyToOne
	@JoinColumn(name="cart_id")
	@JsonIgnore
	private Cart cart;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getQuantity() {
		// TODO Auto-generated method stub
		return 0;
	}
	public Product getProduct() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setQuantity(int i) {
		// TODO Auto-generated method stub
		
	}
	public void setTotalPrice(double d) {
		// TODO Auto-generated method stub
		
	}
	public void setProduct(Product product2) {
		// TODO Auto-generated method stub
		
	}
	public void setCart(Cart cart2) {
		// TODO Auto-generated method stub
		
	}
	public double getTotalPrice() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
