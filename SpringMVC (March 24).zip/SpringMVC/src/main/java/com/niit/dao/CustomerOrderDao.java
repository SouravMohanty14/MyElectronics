package com.niit.dao;

public interface CustomerOrderDao {

}
