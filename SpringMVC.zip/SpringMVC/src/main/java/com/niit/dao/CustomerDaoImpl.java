package com.niit.dao;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.niit.model.Authorities;
import com.niit.model.Customer;

public class CustomerDaoImpl implements CustomerDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	Logger logger = Logger.getLogger(CustomerDaoImpl.class);
	public void saveCustomer(Customer customer) {
		Session session = sessionFactory.openSession();
		logger.debug("==============================");
		//child tables - Users, billingAddress,ShippingAddress
		
		customer.getUsers().setEnabled(true);
		
		//Assignment
		String username = customer.getUsers().getUsername();
		String role="ROLE_USER";
				
		Authorities authorities = new Authorities();
		//set the value
		session.save(customer);
	}
	{
	Cart cart = new Cart();
	customer.setCart(cart);
	
	cart.setCustomer(customer); 
	// update cart set customer_id=? , grandtotal=? 
	
	session.save(customer)
	
	logger.debug("========================");
	session.flush();
	session.close();
	}
	public Customer getCustomerByUsername(String username) {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from Users where username=?");
		query.setString(0,  username);
		Users users = (Users)query.uniqueResult();
		Customer customer = users.getCustomer();
		session.close();
		return customer;
		
	}

}
