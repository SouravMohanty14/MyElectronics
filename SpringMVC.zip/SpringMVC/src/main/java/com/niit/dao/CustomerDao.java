package com.niit.dao;

public interface CustomerDao {

}
